import { T } from '../../theme'
import { CherryBlossom, LotusFlower, Mountains } from '../botanical'

export function FoldedBackground() {
  return (
    <div style={{ position:'fixed', inset:0, zIndex:0, overflow:'hidden', pointerEvents:'none' }}>
      <div style={{ position:'absolute', inset:0, background:'linear-gradient(155deg,#FDF0EF 0%,#FAFAF8 42%,#FBF3F2 100%)' }} />
      <div style={{ position:'absolute', top:'-15%', left:'-12%', width:'68%', height:'58%', background:'radial-gradient(ellipse,rgba(245,214,214,0.38) 0%,transparent 68%)', transform:'rotate(-3deg)' }} />
      <div style={{ position:'absolute', top:0, right:0, width:'48%', height:'52%', background:'radial-gradient(ellipse at top right,rgba(212,221,211,0.3) 0%,transparent 68%)' }} />
      <div style={{ position:'absolute', bottom:0, left:0, width:'45%', height:'38%', background:'radial-gradient(ellipse at bottom left,rgba(245,214,214,0.24) 0%,transparent 65%)' }} />
      <div style={{ position:'absolute', top:0, bottom:0, left:'33%', width:1, background:'linear-gradient(to bottom,transparent 0%,rgba(201,169,110,0.12) 12%,rgba(201,169,110,0.07) 85%,transparent 100%)', transform:'rotate(1.4deg)', transformOrigin:'top' }} />
      <div style={{ position:'absolute', top:'28%', left:0, right:0, height:1, background:'linear-gradient(to right,transparent,rgba(201,169,110,0.09) 22%,rgba(201,169,110,0.05) 78%,transparent)', transform:'rotate(-0.9deg)' }} />
      <div style={{ position:'absolute', top:0, height:'72%', left:'62%', width:1, background:'linear-gradient(to bottom,transparent,rgba(201,169,110,0.07) 30%,transparent 80%)', transform:'rotate(-1.6deg)', transformOrigin:'top' }} />
      <div style={{ position:'absolute', top:'5%', right:0, width:18, bottom:'10%', background:'linear-gradient(to left,rgba(44,40,37,0.045),transparent)' }} />
      <div style={{ position:'absolute', bottom:0, left:'8%', right:'8%', height:14, background:'linear-gradient(to top,rgba(44,40,37,0.035),transparent)' }} />
      <div className="sway" style={{ position:'absolute', top:-28, right:-18, width:245, height:260, opacity:0.56 }}>
        <CherryBlossom />
      </div>
      <div className="bloom" style={{ position:'absolute', bottom:88, left:-18, width:178, height:190, opacity:0.44 }}>
        <LotusFlower />
      </div>
      <div style={{ position:'absolute', bottom:0, left:0, right:0, opacity:0.52 }}>
        <Mountains />
      </div>
    </div>
  )
}

const NAV_ITEMS = [
  { id:'home',       label:'Home',       icon: () => <svg width="22" height="22" fill="none" viewBox="0 0 24 24"><path d="M3 9.5L12 3l9 6.5V21a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z" strokeWidth="1.5" stroke="currentColor" fill="none"/><path d="M9 22V12h6v10" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round"/></svg> },
  { id:'emotions',   label:'Emotions',   icon: () => <svg width="22" height="22" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" strokeWidth="1.5" stroke="currentColor"/><circle cx="12" cy="12" r="3.5" strokeWidth="1.2" stroke="currentColor"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round"/></svg> },
  { id:'oils',       label:'Oils',       icon: () => <svg width="22" height="22" fill="none" viewBox="0 0 24 24"><path d="M12 2C8 8 5 11 5 15a7 7 0 0014 0c0-4-3-7-7-13z" strokeWidth="1.5" stroke="currentColor" fill="none"/><path d="M9 16c0 1.7 1.3 3 3 3" strokeWidth="1.5" stroke="currentColor" strokeLinecap="round"/></svg> },
  { id:'journal',    label:'Journal',    icon: () => <svg width="22" height="22" fill="none" viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2" strokeWidth="1.5" stroke="currentColor" fill="none"/><path d="M8 4v16M11 9h5M11 13h5M11 17h3" strokeWidth="1.4" stroke="currentColor" strokeLinecap="round"/></svg> },
]

export function BottomNav({ current, nav }) {
  const active = ['emotion-detail'].includes(current) ? 'emotions'
               : current === 'oil-detail' ? 'oils' : current
  return (
    <div style={{ position:'fixed', bottom:0, left:'50%', transform:'translateX(-50%)', width:'100%', maxWidth:480, background:'rgba(253,240,239,0.9)', backdropFilter:'blur(24px)', WebkitBackdropFilter:'blur(24px)', borderTop:'1px solid rgba(201,169,110,0.2)', display:'flex', zIndex:200, paddingBottom:'env(safe-area-inset-bottom,0px)' }}>
      {NAV_ITEMS.map(item => {
        const on = active === item.id
        return (
          <button key={item.id} onClick={() => nav(item.id)}
            style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:3, padding:'10px 0 8px', background:'none', border:'none', cursor:'pointer', color:on ? T.gold : T.inkM, transition:'color .2s' }}>
            <span style={{ transform:on ? 'scale(1.12)' : 'scale(1)', transition:'transform .2s' }}>
              <item.icon />
            </span>
            <span style={{ fontFamily:"'DM Sans',sans-serif", fontSize:10, letterSpacing:'0.09em', textTransform:'uppercase', fontWeight:on ? 500 : 400 }}>
              {item.label}
            </span>
            {on && <div style={{ width:18, height:1.5, background:T.gold, borderRadius:1, marginTop:1 }} />}
          </button>
        )
      })}
    </div>
  )
}
