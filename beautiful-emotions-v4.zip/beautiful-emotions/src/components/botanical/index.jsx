// ── Cherry Blossom Branch ─────────────────────────────────────────────────────
function Blossom({ cx, cy, r = 9, pr = 3.8 }) {
  const pts = [0,72,144,216,288].map(a => {
    const rad = (a - 90) * Math.PI / 180
    return [cx + r * Math.cos(rad), cy + r * Math.sin(rad)]
  })
  return (
    <g>
      {pts.map(([px, py], i) => (
        <ellipse key={i} cx={px} cy={py} rx={pr * 0.7} ry={pr}
          transform={`rotate(${i*72} ${px} ${py})`}
          fill="rgba(245,214,214,0.25)" stroke="#C9A96E" strokeWidth="0.75" />
      ))}
      <circle cx={cx} cy={cy} r={2.2} fill="#E8D5B0" stroke="#C9A96E" strokeWidth="0.6" />
    </g>
  )
}

export function CherryBlossom() {
  return (
    <svg viewBox="0 0 240 250" fill="none" width="100%" height="100%">
      <path d="M8 245 Q55 170 92 112 Q122 65 158 22" stroke="#C9A96E" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M92 112 Q118 88 152 72" stroke="#C9A96E" strokeWidth="1" strokeLinecap="round" />
      <path d="M70 140 Q100 118 128 108" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" />
      <path d="M48 178 Q78 160 100 150" stroke="#C9A96E" strokeWidth="0.7" strokeLinecap="round" />
      <path d="M115 55 Q132 42 148 36" stroke="#C9A96E" strokeWidth="0.6" strokeLinecap="round" />
      <Blossom cx={158} cy={22}  r={11} pr={4.2} />
      <Blossom cx={152} cy={72}  r={10} pr={3.8} />
      <Blossom cx={128} cy={108} r={9}  pr={3.5} />
      <Blossom cx={100} cy={150} r={9}  pr={3.4} />
      <Blossom cx={148} cy={36}  r={8}  pr={3.2} />
      <Blossom cx={120} cy={90}  r={8}  pr={3.0} />
      <circle cx={142} cy={58} r={2}    fill="#F5D6D6" stroke="#C9A96E" strokeWidth="0.6" />
      <circle cx={108} cy={130} r={1.6} fill="#F5D6D6" stroke="#C9A96E" strokeWidth="0.6" />
      <circle cx={165} cy={48} r={1.6}  fill="#F5D6D6" stroke="#C9A96E" strokeWidth="0.6" />
      <ellipse cx={188} cy={108} rx={5}   ry={8.5} transform="rotate(38 188 108)"  fill="rgba(245,214,214,0.35)" stroke="#C9A96E" strokeWidth="0.5" />
      <ellipse cx={205} cy={158} rx={4}   ry={7}   transform="rotate(-22 205 158)" fill="rgba(245,214,214,0.28)" stroke="#C9A96E" strokeWidth="0.45" />
      <ellipse cx={220} cy={200} rx={3.5} ry={6}   transform="rotate(12 220 200)"  fill="rgba(245,214,214,0.22)" stroke="#C9A96E" strokeWidth="0.4" />
    </svg>
  )
}

// ── Lotus Flower ──────────────────────────────────────────────────────────────
export function LotusFlower() {
  return (
    <svg viewBox="0 0 180 188" fill="none" width="100%" height="100%">
      <path d="M15 148 Q90 132 165 148" stroke="#C9A96E" strokeWidth="0.6" opacity="0.5" />
      <path d="M48 150 Q90 130 132 150 Q90 156 48 150 Z" fill="rgba(143,166,142,0.18)" stroke="#8FA68E" strokeWidth="0.8" />
      <path d="M90 138 Q68 106 72 72 Q90 88 108 72 Q112 106 90 138 Z" fill="rgba(245,214,214,0.22)" stroke="#C9A96E" strokeWidth="0.9" />
      <path d="M90 138 Q56 114 46 80 Q68 82 78 58 Q96 80 90 138 Z" fill="rgba(245,214,214,0.18)" stroke="#C9A96E" strokeWidth="0.85" />
      <path d="M90 138 Q124 114 134 80 Q112 82 102 58 Q84 80 90 138 Z" fill="rgba(245,214,214,0.18)" stroke="#C9A96E" strokeWidth="0.85" />
      <path d="M90 138 Q48 122 36 90 Q58 96 60 68 Q78 90 90 138 Z" fill="rgba(245,214,214,0.14)" stroke="#C9A96E" strokeWidth="0.8" />
      <path d="M90 138 Q132 122 144 90 Q122 96 120 68 Q102 90 90 138 Z" fill="rgba(245,214,214,0.14)" stroke="#C9A96E" strokeWidth="0.8" />
      <path d="M90 136 Q74 112 76 90 Q90 102 104 90 Q106 112 90 136 Z" fill="rgba(232,160,160,0.28)" stroke="#C9A96E" strokeWidth="0.8" />
      <path d="M90 136 Q64 116 66 92 Q80 100 82 80 Q94 100 90 136 Z" fill="rgba(232,160,160,0.22)" stroke="#C9A96E" strokeWidth="0.7" />
      <path d="M90 136 Q116 116 114 92 Q100 100 98 80 Q86 100 90 136 Z" fill="rgba(232,160,160,0.22)" stroke="#C9A96E" strokeWidth="0.7" />
      <circle cx={90} cy={104} r={9}   fill="rgba(232,213,176,0.45)" stroke="#C9A96E" strokeWidth="0.9" />
      <circle cx={90} cy={104} r={3.5} fill="#E8D5B0"               stroke="#C9A96E" strokeWidth="0.7" />
    </svg>
  )
}

// ── Himalayan Mountains + Tea Fields ──────────────────────────────────────────
export function Mountains() {
  return (
    <svg viewBox="0 0 480 130" preserveAspectRatio="xMidYMax meet" fill="none" width="100%" height="130">
      <path d="M0 130 L45 62 L88 84 L138 28 L190 68 L232 22 L280 55 L328 36 L376 68 L412 44 L448 58 L480 42 L480 130 Z"
        fill="rgba(212,221,211,0.2)" stroke="rgba(201,169,110,0.18)" strokeWidth="0.5" />
      <path d="M0 130 L52 52 L105 76 L152 32 L202 62 L244 18 L295 50 L348 28 L396 58 L440 38 L480 52 L480 130 Z"
        fill="rgba(212,221,211,0.25)" stroke="rgba(201,169,110,0.22)" strokeWidth="0.6" />
      <path d="M152 32 L144 50 L160 50 Z" fill="rgba(250,248,245,0.65)" stroke="rgba(201,169,110,0.3)"  strokeWidth="0.5" />
      <path d="M244 18 L234 40 L254 40 Z" fill="rgba(250,248,245,0.7)"  stroke="rgba(201,169,110,0.3)"  strokeWidth="0.5" />
      <path d="M348 28 L338 48 L358 48 Z" fill="rgba(250,248,245,0.6)"  stroke="rgba(201,169,110,0.28)" strokeWidth="0.5" />
      <path d="M0 130 Q55 108 110 116 Q165 102 220 112 Q275 100 330 110 Q385 102 440 112 Q460 108 480 114 L480 130 Z"
        fill="rgba(143,166,142,0.2)" stroke="rgba(143,166,142,0.32)" strokeWidth="0.5" />
      {[18,55,100,148,195,238,278,320,362,405,448].map((x, i) => (
        <path key={i} d={`M${x} ${118+(i%2)*4} Q${x+12} ${114+(i%2)*4} ${x+24} ${118+(i%2)*4}`}
          stroke="rgba(143,166,142,0.48)" strokeWidth="0.4" />
      ))}
    </svg>
  )
}
